package control;

import java.util.Scanner;
import java.util.Arrays;
import robot.Robot;

// Robot Assignment for Programming 1 s2 2016
// Adapted by Caspar from original Robot code in RobotImpl.jar written by Dr Charles Thevathayan
public class RobotControl implements Control
{
	

	private static final int MAX_HEIGHT = 13;

	private int height = 2;
	private int width = 1;
	private int depth = 0;
	
	int numBars = 0;
	private int numBlocks = 0;
	
	
	//scanner
	private Scanner keyboard = new Scanner(System.in); //scanner

	private Robot robot;
	
	private void numBarsValid(){
		
		if (keyboard.hasNextInt())	{
			numBars = keyboard.nextInt(); //if input isn't an integer it equals 0
		}	else {
			keyboard.next();
			numBars = 0;
		}
	} 
	
	private void numBlocksValid(){
		
		if (keyboard.hasNextInt())	{
			numBlocks = keyboard.nextInt(); //if input isn't an integer it equals 0
		}	else {
			keyboard.next();
			numBlocks = 0;
		}
	
	}
	
	
	// called by RobotImpl
	// the unused arrays are based on cmd line params to RobotImpl not used in this assignment
	@Override
	public void control(Robot robot, int barHeightsUnused[],
			int blockHeightsUnused[])
	{
		// save robot so we can access it from other methods
		this.robot = robot;
		
		
		// ASSIGNMENT PART A
		// replace this code with a console based menu to populate the arrays
		
		//number of bars
		System.out.print("Enter number of bars (min 1/max 6):");
		
		
		numBarsValid();
		while((numBars<1  || numBars>6) ){ //if input isn't between 1-6 it will error and start again
			
			System.out.println("error");
			System.out.println("Enter number of bars (min 1/max 6):");
			numBarsValid();
		}
		
			
		
		
			
		
		// select bar heights
		
		int barHeights[] = new int[numBars];
		for(int i=0;i<numBars;i++){ // creates an array of inputed numbers for as long as i is less than numBars
			System.out.println("Enter height of bar "+ (i+1) +" of "+numBars+" (min 1/max 7):");
				if(keyboard.hasNextInt())	{
				barHeights[i] = keyboard.nextInt();// if input isn't an int it loops to the start
				}	else {
					keyboard.next();
					
					
				}
			
			while((barHeights[i]<1  || barHeights[i]>7) ){//input must be between 1-7
			
				System.out.println("error");
				System.out.println("Enter height of bar "+ (i+1) +" of "+numBars+" (min 1/max 7):");
				if(keyboard.hasNextInt())	{
					barHeights[i] = keyboard.nextInt();
				}	else {
					keyboard.next();
					barHeights[i] = 0;
					
				}
			}
		
		}
		
		
		//blocks
		System.out.println("Enter number of blocks (min 1/max 6):");
		numBlocksValid();
		while((numBlocks<1  || numBlocks>6) ){//input between 1-6
			
			System.out.println("error");
			System.out.println("Enter number of blocks (min 1/max 6):");
			numBlocksValid();
		}
		
		
		
		int blockHeights[] = new int[numBlocks];
		for(int i=0;i<numBlocks;i++){//runs the loop until i is equal too numBlocks
			System.out.println("Enter height of block " + (i+1) + " of " + numBlocks + " (min 1 max 3):");
			if(keyboard.hasNextInt())	{
				blockHeights[i] = keyboard.nextInt();
			}	else {
				keyboard.next();
				blockHeights[i]	= 0;
			}
		
		
			while((blockHeights[i]<1  || blockHeights[i]>3) ){
				
			System.out.println("error");
			System.out.println("Enter height of block " + (i+1) + " of " + numBlocks + " (min 1 max 3):");
			if(keyboard.hasNextInt())	{
				blockHeights[i] = keyboard.nextInt();
			}	else {
				keyboard.next();
				blockHeights[i]	= 0;
			}
		
		
		}
		
		}
		
		System.out.println("Input Successfully Completed");
		//Complete 
	

		// initialise the robot
		robot.init(barHeights, blockHeights, height, width, depth);

		// a simple private method to demonstrate how to control (assignment PART B)
		moveToHeight(MAX_HEIGHT);
		
		// assignment part B implemented here
	}

	private void moveToHeight(int height)
	{
		while (this.height < height)
		{
			robot.up();
			this.height++;
		}
	}
	
	// assignment part B methods implemented here
	int targetHeight1 = 0;
	int targetHeight2 = 0;
	int initialBlock = 0;
	int initialBar = 0;
	int blockHeight = blockHeights[initialBlock];
	int sourceHeight = 0;
	int[] minBarHeight = barHeights;
	
	
	

	while (initialBlock < blockHeights.length) {
		sourceHeight += blockHeight[initialBlock];
		initialBlock++;
	}

	initialBlock--;

	 

	
	final int distanceArmExtend = 10;//creating variables 
	final int depthSecondArm = 1;
	int currentBar = 0;
    int contractAmt;
    
	while (initialBlock >= 0) {//starting another while loop, while the initial clock is grater than or = to 0
		Arrays.sort(minBarHeight);
		int maxBarHeight = minBarHeight[minBarHeight.length - 1];
		
		while (height <  maxBarHeight+1) {
			robot.up();
			height++;
			if (height > maxBarHeight+2) {
				robot.down();
				height--;
			}
		}
		while (height < sourceHeight+1)  {
			robot.up();
			height++;
		}
		blockHeight = blockHeight[initialBlock];
		switch (blockHeight) {
		case 1:
			contractAmt = 9; 
			break;
		case 2:
			contractAmt = 8; 
			break;
		case 3:
			contractAmt = distanceArmExtend - currentBar - 3; 
			break;
		default:
			contractAmt = 9;
			break;
		}
		while (width < distanceArmExtend) {// Bringing second arm to column 10
			robot.extend();// moving 1 step horizontally
			width++;// Current width of second arm being incremented by 1
		}
		while (height - depth > sourceHeight + 1) {
			robot.lower();// lowering the third arm
			depth++;// depth of arm three being incremented by 1 
		}
		robot.pick();// picking the top block on column 10
		sourceHeight -= blockHeight;// when top block is selected the height of the source will decrease
		while (height < maxBarHeight + blockHeight + 1) {
			robot.up();//moves the robot up 1 in height
			// Current height of arm1 being incremented by 1
			height++;
		}

		int heightMaxRaiseBackwards= sourceHeight;//make new variable equal original source height variable 
       
		if (blockHeight == 1) {//condition block height =1 
			//start of for loop 
				if (maxBarHeight > heightMaxRaiseBackwards) {
					heightMaxRaiseBackwards= maxBarHeight;
				}
			
			if (heightMaxRaiseBackwards< targetHeight2) {
				heightMaxRaiseBackwards= targetHeight2;
			}
			if (heightMaxRaiseBackwards< targetHeight1) {
				heightMaxRaiseBackwards= targetHeight1;
			}
			
			
		} else if (blockHeight == 2) {
				if (maxBarHeight > heightMaxRaiseBackwards) {
					heightMaxRaiseBackwards= maxBarHeight;
				}
			
			if (heightMaxRaiseBackwards< targetHeight2) {
				heightMaxRaiseBackwards= targetHeight2;
			}
			
			
		} else if (blockHeight == 3) {
				if (maxBarHeight > heightMaxRaiseBackwards) {
					heightMaxRaiseBackwards = maxBarHeight;
				}
			
		}

		// raising third arm to the optimistic height according to
		// heightMaxRaiseBackward
		while (height - depthSecondArm - heightMaxRaiseBackwards< depth + blockHeight) {
			robot.raise();
			depth--;
		}

		while (contractAmt > 0) {
			robot.contract();
			contractAmt--;
			width--;
		}

		// lowering third arm
		if (blockHeight == 1) {
			while ((height - 1) - depth - blockHeight > targetHeight1) {
				robot.lower();
				depth++;
			}

			// dropping the block
			robot.drop();
			while (depth > 0) {
				robot.raise();
				depth--;
			}
				
			
				
			// The height of currentBar increases by block just placed
			targetHeight1 += blockHeight;

		} else if (blockHeight == 2) {
			while ((height - 1) - depth - blockHeight > targetHeight2) {
				robot.lower();
				depth++;
			}

			// dropping the block
			robot.drop();
			while (depth > 0) {
				robot.raise();
				depth--;
			}


			// The height of currentBar increases by block just placed
			targetHeight2 += blockHeight;

		} else if (blockHeight == 3) {
			while ((height - 1) - depth - blockHeight > barHeights[currentBar]) {
				robot.lower();
				depth++;
			}

			// dropping the block
			robot.drop();
			while (depth > 0) {
				robot.raise();
				depth--;
			}


			// The height of currentBar increases by block just placed
			barHeights[currentBar] += blockHeight;
		}

		int heightMaxRaiseFowards = sourceHeight;

		if (blockHeight == 1) {
			
				if (maxBarHeight > heightMaxRaiseFowards) {
					heightMaxRaiseFowards = maxBarHeight;
				}
			
			if (heightMaxRaiseFowards < targetHeight2) {
				heightMaxRaiseFowards = targetHeight2;
			}

			// raising the third arm to the optimistic height according to
			// heightMaxRaiseFowards
			if (targetHeight1 < heightMaxRaiseFowards) {
				if (sourceHeight > 0) {
					while (depth > height - depthSecondArm - heightMaxRaiseFowards) {
						robot.raise();
						depth--;
						
					}
				}
				if (height>maxBarHeight+1){
					while (height > maxBarHeight){
					robot.down();
					height--;
					}
				}
			}
		} else if (blockHeight == 2) {
			
				if (maxBarHeight > heightMaxRaiseFowards) {
					heightMaxRaiseFowards = maxBarHeight;
				}
			

			// raising the third arm to the optimistic height according to
			// heightMaxRaiseFowards
			if (targetHeight2 < heightMaxRaiseFowards) {
				if (sourceHeight > 0) {
					while (depth > height - depthSecondArm - heightMaxRaiseFowards) {
						robot.raise();
						depth--;
					}
				}
				if (height>maxBarHeight+1){
					while (height > maxBarHeight){
					robot.down();
					height--;
					}
				}
			}
			
		} else if (blockHeight == 3) {
				while (barHeights[currentBar] > heightMaxRaiseFowards) {
					 heightMaxRaiseFowards = barHeights[currentBar];
				}
			

			// raising the third arm to the optimistic height according to
			// heightMaxRaiseFowards
			if (barHeights[currentBar] < heightMaxRaiseFowards) {
				if (sourceHeight > 0) {
					while (depth > height - depthSecondArm - heightMaxRaiseFowards) {
						robot.raise();
						depth--;
					}
				}
				if (height>maxBarHeight+1){
					while (height > maxBarHeight){
					robot.down();
					height--;
					}
				}
			}
		}

		// point to the next bar if block height = 3
		if (blockHeight == 3) {
			barHeights[currentBar]++;
		}

		// point to the next block
		// topmost block is assumed to be 3 for parts (a) and (b)
		blockHeight = blockHeight[initialBlock--];

	}
}
}
	
}
